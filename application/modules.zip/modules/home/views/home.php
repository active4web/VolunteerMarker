

    <!-- Preloader Begin -->
    
    <?php
                
                foreach($home_page as $home_page)
                foreach($site_info as $site_info)
                ?>
    <!-- Offcanvas Begin -->
    <div class="offcanvas-overlay fixed-top w-100 h-100"></div>

    <!-- Offcanvas End -->

    <!-- Slider Begin -->
    <section class=" section-pattern bg pt-130 pb-50">
        <!-- Banner Slider Begin -->
        <div class="container">
         <div class="row">
                <div class="col-md-5 col-ms-12">
                    <!-- Section Title Begin -->
                    <div class="section-title text-center" style="background-color: #fff;padding: 10px; border: 2px solid #fff;">
                        <p class="p" style="color: #000;margin-top: 7px; font-size: 15px; text-align: center;"> نظام المساعدات المركزي     </p>
                       <form method="POST" action="#" class="contact-form">
                            <div class="row">
                                
                                 <div class="col-md-12" id="city_search">

<select name="register_type" class="theme-input-style" id="register_type">
                                       <option value="0">تسجيل مؤسسة</option>
                                        <option value="1">تسجيل كمتطوع</option>
                                       <option value="2">تسجيل طلب مساعدة</option>

                                      </select>
                                      </div>
                                      <div class="row foundation" style="margin:0px">
                                <div class="col-md-12 foundation">
                                                                       <label>اسم المؤسسة</label>

                                    <input type="text" name="name" class="theme-input-style" placeholder="اسم المؤسسة">
                                </div>
                               <div class="col-md-12 foundation">
                                   <label>البريد الألكترونى</label>
                            <input type="text" name="name" class="theme-input-style" placeholder="البريد الالكترونى">

                                </div>
                                  <div class="col-md-12 foundation" >
                                         <label>رقم الحوال</label>
                                    <input type="text" name="name" class="theme-input-style" placeholder="رقم الجوال">
                                   </div> 
                                <div class="col-md-12 foundation">
                                             <label>الدولة</label>
                                    <input type="text" name="name" class="theme-input-style" placeholder="الدولة">
                                   </div>
                                   <div class="col-md-12 foundation" >
                                        <label>المحافظة</label>
                                    <input type="text" name="name" class="theme-input-style" placeholder="المحافظة">
                                   </div>
                                   <div class="col-md-12 foundation">
                                <label>الاقليم</label>

                                    <input type="text" name="name" class="theme-input-style" placeholder="الاقليم">
                                   </div>
                                
<div class="col-md-12 foundation" id="city_search">
    <label>نوع التسجيل</label>
<select name="course_key" class="theme-input-style" id="course_key_search">
    <option value="1">تقديم مساعدة</option>
	<option value="2">طلب تطوع</option>
</select>
</div>
                                   
                    </div>
                    
                                   
                                   
                 <div class="row volunteer" style="display:none;margin:0px">
                                <div class="col-md-12 volunteer">
                                     <label>الاسم</label>
                                    <input type="text" name="name" class="theme-input-style" placeholder="الاسم">
                                </div>
                               <div class="col-md-12 volunteer">
                                   <label>رقم الهوية</label>
                            <input type="text" name="name" class="theme-input-style" placeholder="رقم الهوية">

                                </div>
                                
                                <div class="col-md-12 volunteer">
                                    <label>البريد الألكترونى</label>
                                    <input type="text" name="name" class="theme-input-style" placeholder="البريد الالكترونى">
                                   </div>
                                   <div class="col-md-12 volunteer">
                                       <label>رقم الجوال</label>
                                    <input type="text" name="name" class="theme-input-style" placeholder="رقم الجوال">
                                   </div>  
                         
                                   <div class="col-md-12 volunteer" >
                                       <label>الدولة</label>
                                    <input type="text" name="name" class="theme-input-style" placeholder="الدولة">
                                   </div>
                                   <div class="col-md-12 volunteer">
                                       <label>المحافظة</label>
                                    <input type="text" name="name" class="theme-input-style" placeholder="المحافظة">
                                   </div>
                                         <div class="col-md-12 foundation">
                                <label>الاقليم</label>

                                    <input type="text" name="name" class="theme-input-style" placeholder="الاقليم">
                                   </div>
                                  <div class="col-md-12 volunteer" >
                                      <label>مجال التطوع</label>
                                    <input type="text" name="name" class="theme-input-style" placeholder="مجال التطوع ">
                                   </div> 
                                  <div class="col-md-12 volunteer">
                                      <label>الوقت المتاح لتطوعك</label>
                                    <input type="date" name="name" class="theme-input-style" placeholder="الوقت المتاح لتطوعك">
                                   </div>                                    
                                   
                                   

                                   
                    </div>
                    
                    <div class="row help_request" style="display:none;margin:0px">
                                <div class="col-md-12 help_request">
                                    <label>الاسم</label>
                                    <input type="text" name="name" class="theme-input-style" placeholder="الاسم">
                                </div>
                             
                                <div class="col-md-12 help_request">
                                    <label>البريد الألكترونى</label>
                                    <input type="text" name="name" class="theme-input-style" placeholder="البريد الالكترونى">
                                   </div>
                                   <div class="col-md-12 help_request">
                                       <label>رقم الجوال</label>
                                    <input type="text" name="name" class="theme-input-style" placeholder="رقم الجوال">
                                   </div>  
                                   
                                   <div class="col-md-12 help_request" >
                                        <label>الدولة</label>
                                    <input type="text" name="name" class="theme-input-style" placeholder="الدولة">
                                   </div>
                                   <div class="col-md-12 help_request">
                                        <label>المحافظة</label>
                                    <input type="text" name="name" class="theme-input-style" placeholder="المحافظة">
                                   </div>
                                         <div class="col-md-12 foundation">
                                <label>الاقليم</label>

                                    <input type="text" name="name" class="theme-input-style" placeholder="الاقليم">
                                   </div>
                                  <div class="col-md-12 help_request" >
                                       <label>نوع المساعدة</label>
                                    <input type="text" name="name" class="theme-input-style" placeholder=" نوع المساعدة">
                                   </div> 
                                                
                                     <div class="col-md-12 help_request" id="city_search">
<label>المؤسسة المساعدة</label>
<select name="course_key" class="theme-input-style" id="course_key_search">
    <option value="1">تقديم مساعدة</option>
	<option value="2">طلب تطوع</option>
</select>
</div>
                                   
                    </div>
                    
                                <div class="col-12">
                                    <button type="submit" class="btn searchbutton mainheader" style="background-color:#367dfe !important;width:100%">
                                       <span>تسجيل الأن</span></button>
                                </div>
                            </div>
                            <div class="form-response"></div>
                        </form>
                    </div>
                    
                    
               
                </div>
                <div class="col-md-1 col-ms-12"></div>
                <div class="col-md-6 col-ms-12">
                  <img src="<?= DIR_DES_STYLE?>site_setting/<?=$home_page->slider_background?>" style="width:100%">
                </div>
            </div>
              
                   
             </div>
        <!-- Banner Slider End -->
    </section>
    <!-- Slider End -->

  
    <section class=" section-pattern  pt-50 pb-50" style="margin-top:0px;">
        <!-- Banner Slider Begin -->
        <div class="container">
         
              <div class="row" >
                      <div class="col-md-4 col-ms-12">
                     <img src="<?=DIR_DES_STYLE?>site_setting/<?=$home_page->img_step1?>" style="width:100%">
                     <h3 style="font-size: 20px;text-align: center;color: #2a81ea;line-height: 30px;">Droplets that from infected person coughs or sneezes</h3>
                     <p class="p" style="text-align:center;font-size:15px"><?=$home_page->content_first?></p>
                    </div>
                      <div class="col-md-4 col-ms-12" style="">
                       <img src="<?=DIR_DES_STYLE?>site_setting/<?=$home_page->img_step2?>" style="width:100%"> 
                       <h3 style="font-size: 20px;text-align: center;color: #2a81ea;line-height: 30px;">Touching or contact with infected surfaces or objects</h3>
                        <p class="p" style="text-align:center;font-size:15px"><?=$home_page->content_second?></p>
                    </div>
                      <div class="col-md-4 col-ms-12">
                     <img src="<?=DIR_DES_STYLE?>site_setting/<?=$home_page->img_step3?>" style="width:100%">
                     <h3 style="font-size: 20px;text-align: center;color: #2a81ea;line-height: 30px;">Person-to-person spread as close contact with infected</h3>
                     <p class="p" style="text-align:center;font-size:15px"><?=$home_page->content_third?></p>
                    </div>
                              
                   </div>           
                   
             </div>
        <!-- Banner Slider End -->
    </section>


    


    <!-- CTA Begin -->
    <section class="gradient_bg_db pt-50 pb-80">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <!-- CTA Content Begin -->
                    <div class="cta-content text-center text-white">
                        <hr class="hr">
                        <h2>LATEST UPDATE</h2>
                    </div>
                    <div class="row">
                        
                        <div class="col-md-4 col-ms-12" style="margin-bottom:40px">
                          <div class="blog-item">
                                    <div class="blog-image">
                                        <img src="http://demo.themenio.com/kovid19/images/blog/blog-a.jpg" alt="">
                                    </div>
                                    <div class="blog-text">
                                        <h2 class="title" style="letter-spacing: -0.025em;margin-bottom: 0.875rem;font-size: 1.25rem;"><a href="#">Caring for someone at home</a></h2>
                                        <p>Most people who get sick with COVID-19 will have only mild illness and should recover at home. Care at home can help stop the spread of COVID-19</p>
                                    </div>
                                </div>
                            
                        </div>
                       
                        
                        <div class="col-md-4 col-ms-12" style="margin-bottom:40px">
                          <div class="blog-item">
                                    <div class="blog-image">
                                        <img src="http://demo.themenio.com/kovid19/images/blog/blog-b.jpg" alt="">
                                    </div>
                                    <div class="blog-text">
                                        <h2 class="title" style="letter-spacing: -0.025em;margin-bottom: 0.875rem;font-size: 1.25rem;">
                                            <a href="#">15 ways to keep safe and healthy</a></h2>
                                        <p>Most people who get sick with COVID-19 will have only mild illness and should recover at home. Care at home can help stop the spread of COVID-19</p>
                                    </div>
                                </div>
                            
                        </div>
                       
                       
                       <div class="col-md-4 col-ms-12" style="margin-bottom:40px">
                          <div class="blog-item">
                                    <div class="blog-image">
                                        <img src="http://demo.themenio.com/kovid19/images/blog/blog-c.jpg" alt="">
                                    </div>
                                    <div class="blog-text">
                                        <h2 class="title" style="letter-spacing: -0.025em;margin-bottom: 0.875rem;font-size: 1.25rem;">
                                            <a href="#">If You Think You Are Sick</a></h2>
                                        <p>Most people who get sick with COVID-19 will have only mild illness and should recover at home. Care at home can help stop the spread of COVID-19</p>
                                    </div>
                                </div>
                            
                        </div>
                       
                        
                    </div>
                    <!-- CTA Content End -->
                </div>
            </div>
        </div>
    </section>
    <!-- CTA End -->



  <script type="text/javascript">
    </script>

</body>
</html>