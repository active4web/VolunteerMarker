<?php

(defined('BASEPATH')) OR exit('No direct script access allowed');

class Home extends MX_Controller {
    function __construct() {

		parent::__construct();
        $this->load->library('session');
		$this->load->model('data','','true');
		@date_default_timezone_set('Asia/Riyadh');
		$this->lang->load('main_lang', get_lang() );
        if( isset($this->session->get_userdata('lang')['lang']) ){
        $lang = $this->session->get_userdata('lang')['lang'];
        }else{
        $lang = 'arabic';
        }
        $dir = ( $lang == 'arabic' )? 'left' : 'right' ;
		define( "LANGU" , $lang );
    }
    
	public function lang_site( $lang = null ){
        if( $lang == 'ar' ){
            $newdata = array(
            'lang'  => 'arabic'
            );
            $this->session->set_userdata($newdata);
        }else if( $lang == 'en' ){
            $newdata = array(
            'lang'  => 'english'
            );
            $this->session->set_userdata($newdata);
        }else if( $lang == 'fr' ){
            $newdata = array(
            'lang'  => 'french'
            );
            $this->session->set_userdata($newdata);
		}
		
		//echo  $this->session->get_userdata($newdata);
		//echo $_GET['link'];
 redirect($_GET['link']);
    }
    
    function index() {

		global $lang;
		if( isset($this->session->get_userdata('lang')['lang']) ){
			$lang = $this->session->get_userdata('lang')['lang'];
			}else{
			$lang = 'arabic';
			}
			$data['lang'] =$lang;
$data['site_info'] =$this->db->get_where('site_info')->result(); 
$data_conent['home_page']=$this->db->get_where('home_page')->result();
$data_conent['site_info'] =$this->db->get_where('site_info')->result(); 
	$this->load->view('home/include/head',$data );
$this->load->view('home/include/header',$data );
	$this->load->view('home/home',$data_conent);
	$this->load->view('home/include/footer',$data);
		  
    }

function test() {	$this->load->view('test');}

public function news(){
    global $lang;
		if( isset($this->session->get_userdata('lang')['lang']) ){
			$lang = $this->session->get_userdata('lang')['lang'];
			}else{
			$lang = 'arabic';
			}
			$data['lang'] =$lang;
	$this->load->library('rssparser');
	$data_conent['rss'] = "";
	$feeds = $this->data->get_sql('rss_feeds');
	if(!empty($feeds)){
		foreach($feeds as $feed){
			$rss[] = $this->rssparser->set_feed_url($feed->rss_link)->set_cache_life(30)->getFeed($feed->rss_max);
			//print_r($feed);
			//echo $feed->rss_link;
		}
		$data_conent['rss'] = $rss;
	}
	$data['site_info'] =$this->db->get_where('site_info')->result(); 
	$data_conent['home_page']=$this->db->get_where('home_page')->result();
	$data_conent['site_info'] =$this->db->get_where('site_info')->result(); 
	$this->load->view('home/include/head',$data );
	$this->load->view('home/include/header',$data );
	$this->load->view('home/news',$data_conent );
	$this->load->view('home/include/footer',$data);
}
}


