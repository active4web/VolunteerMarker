<?php
$lang['dashboard'] = 'Dashboard';
$lang['delete_confirm_msg'] = 'Do you really want to delete?';
$lang['success_update'] = 'Successfully Update !';
$lang['edit'] = 'Edit';
$lang['delete'] = 'Delete';
$lang['status'] = 'Status';
$lang['active'] = 'Active';
$lang['not_active'] = 'Deactive';
$lang['choose'] = 'Choose';
$lang['enter'] = 'Enter';
$lang['view'] = 'View';
$lang['update'] = 'Update';
$lang['save'] = 'Save';
$lang['sort'] = 'Sort';

?>