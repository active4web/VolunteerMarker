<?php
$lang['languages'] = 'Languages';
$lang['language'] = 'Language';
$lang['success_add_language'] = 'Successfully Add Language !';
$lang['code'] = 'CODE';
$lang['edit_language'] = 'Edit Language';
$lang['add_new_language'] = 'Add Language';
$lang['icon'] = 'Icon';
$lang['error_isset_language_code'] = 'Sorry this code already exists';
?>