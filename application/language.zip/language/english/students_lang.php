<?php
$lang['students'] = 'Students';
$lang['student'] = 'Student';
$lang['success_add_customer'] = 'Successfully Add Student !';
$lang['edit_student'] = 'Edit Student';
$lang['add_student'] = 'Add Student';
$lang['error_isset_email'] = 'Sorry this Email already exists';
$lang['email'] = 'E-Mail';
$lang['password'] = 'Password';
$lang['confirm_password'] = 'Confirm Password';


?>