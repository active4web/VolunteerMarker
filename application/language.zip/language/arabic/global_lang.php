<?php
$lang['dashboard'] = 'لوحة التحكم';
$lang['delete_confirm_msg'] = 'هل تريد الحذف؟';
$lang['success_update'] = 'تم التحديث بنجاح';
$lang['edit'] = 'تعديل';
$lang['delete'] = 'حذف';
$lang['status'] = 'الحالة';
$lang['active'] = 'مفعل';
$lang['not_active'] = 'غير مفعل';
$lang['choose'] = 'اختر';
$lang['enter'] = 'ادخل';
$lang['view'] = 'عرض';
$lang['update'] = 'تحديث';
$lang['save'] = 'حفظ';
$lang['sort'] = 'ترتيب';

?>