<?php
$lang['settings'] = 'الاعدادات ';
$lang['general_settings'] = 'الاعدادات العامة';
$lang['site_title'] = 'عنوان الموقع';
$lang['site_name'] = 'اسم الموقع';
$lang['site_email'] = 'ايميل الموقع';
$lang['site_description'] = 'وصف الموقع';
$lang['site_keywords'] ='الكلمات الدلالية';
$lang['site_status'] = 'حالة الموقع';
$lang['site_close_msg'] = 'رسالة اغلاق الموقع';
$lang['system_settings'] = 'اعدادات النظام';
$lang['default_theme'] = 'الثيم الافتراضي';
$lang['default_language'] = 'اللغة الافتراضية';
$lang['timezone'] = 'Time Zone';
$lang['allowed_files'] = 'المفات المسموح بها';
$lang['max_file_size'] = 'أقصي حجم للملفات (MB)';
$lang['email_settings'] = 'اعدادات المراسلة';
$lang['sender_email'] = 'ايميل الراسل';
$lang['email_protocol'] = 'Email Protocol';

?>