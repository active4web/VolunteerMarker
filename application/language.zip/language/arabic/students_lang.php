<?php
$lang['students'] = 'الطلاب';
$lang['student'] = 'طالب';
$lang['success_add_customer'] = 'تم اضافة الطالب بنجاح !';
$lang['edit_student'] = 'تعديل الطالب';
$lang['add_student'] = 'اضافة طالب';
$lang['email'] = 'البريد الالكتروني';
$lang['id_num'] = 'الرقم المدني';
$lang['password'] = 'كلمة المرور';
$lang['parent_password'] = 'كلمة مرور ولي الأمر';
$lang['parent_phone'] = 'هاتف ولي الأمر';
$lang['notes'] = 'ملاحظات';
$lang['student_avatar'] = 'صورة الطالب';
$lang['ip'] = 'IP';
$lang['this_id_num_already_exists'] = 'الرقم المدني الذى ادخلته موجود من قبل';
?>