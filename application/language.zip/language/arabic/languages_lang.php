<?php
$lang['languages'] = 'اللغات';
$lang['language'] = 'لغة';
$lang['success_add_language'] = 'تم اضافة اللغة بنجاح !';
$lang['code'] = 'كود';
$lang['edit_language'] = 'تعديل اللغة';
$lang['add_new_language'] = 'اضافة لغة';
$lang['icon'] = 'Icon';
$lang['error_isset_language_code'] = 'الكود المستخدم موجود من قبل';
$lang['name'] = 'الاسم';
?>